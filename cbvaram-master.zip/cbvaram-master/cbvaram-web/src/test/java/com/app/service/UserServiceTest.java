package com.app.service;

import com.app.SpringBootWebApplication;
import com.app.entity.AppUser;
import com.app.repository.UserRepository;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.BDDMockito.given;
import static org.mockito.Matchers.anyString;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = { SpringBootWebApplication.class })
public class UserServiceTest {

    @Autowired
    private UserService userService;

    @MockBean
    private UserRepository userRepository;

    @Test
    public void test_findByUsername() {
        AppUser user = new AppUser();
        user.setUsername("user");
        user.setPassword("password");
        given(userRepository.findByUsername(anyString())).willReturn(user);

        AppUser appUser = userService.findByUsername("user");
        assertThat(appUser.getUsername(), is(equalTo(user.getUsername())));
    }
}
