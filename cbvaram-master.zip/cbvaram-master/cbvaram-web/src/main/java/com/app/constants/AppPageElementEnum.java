package com.app.constants;

public enum AppPageElementEnum {
    TITLE {
        @Override
        public String toString() {
            return "title";
        }
    }
}
