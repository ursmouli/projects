package com.app.constants;

public enum AppPageNameEnum {
    LOGIN {
        @Override
        public String toString() {
            return "/login";
        }
    },
    REG_PAGE {
        @Override
        public String toString() {
            return "/register-user";
        }
    },
    HOME {
        @Override
        public String toString() {
            return "/home";
        }
    },
    ABOUT {
        @Override
        public String toString() {
            return "/about";
        }
    },
    USER_HOME {
        @Override
        public String toString() {
            return "/user_home";
        }
    },
    ADMIN_HOME {
        @Override
        public String toString() {
            return "/admin_home";
        }
    },
    ERROR_403 {
        @Override
        public String toString() {
            return "/error/403";
        }
    }
}
