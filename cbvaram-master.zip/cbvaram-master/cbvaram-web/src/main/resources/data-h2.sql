-- application users
insert into app_user (id, username, password, email) values (1, 'appuser', '$2a$10$yjV7T800G.mdmuAvKYoVJ.km5VtApmkXDiVIr9eaNrfHA1xfMl.9C', 'user@mail.com');
insert into app_user (id, username, password, email) values (2, 'appadmin', '$2a$10$yjV7T800G.mdmuAvKYoVJ.km5VtApmkXDiVIr9eaNrfHA1xfMl.9C', 'admin@mail.com');

-- user roles
insert into role (id, name) values (1, 'ROLE_USER');
insert into role (id, name) values (2, 'ROLE_ADMIN');

-- user roles mapping
insert into user_role (user_id, role_id) values (1, 1);
insert into user_role (user_id, role_id) values (2, 2);

insert into country (country_id, country_code, country_name) values (1, 'IND', 'India');
insert into country (country_id, country_code, country_name) values (2, 'MY', 'Malaysia');

-- india states
insert into state (state_id, state_code, state_name, fk_country_id) values (1, 'AP', 'Andhra Pradesh', 1);
insert into state (state_id, state_code, state_name, fk_country_id) values (2, 'KA', 'Karnataka', 1);
insert into state (state_id, state_code, state_name, fk_country_id) values (3, 'TN', 'Tamil Nadu', 1);
insert into state (state_id, state_code, state_name, fk_country_id) values (4, 'KL', 'Andhra Pradesh', 1);
-- Malaysia states
insert into state (state_id, state_code, state_name, fk_country_id) values (5, 'KL', 'Kuala Lumpur', 2);
insert into state (state_id, state_code, state_name, fk_country_id) values (6, 'SL', 'Selangor', 2);