package com.app.controller;

import com.app.constants.AppPageElementEnum;
import com.app.constants.AppPageNameEnum;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class LoginController {

    @GetMapping("/login")
    public String login(Model model) {
        model.addAttribute(AppPageElementEnum.TITLE.toString(), "Login Page");
        return AppPageNameEnum.LOGIN.toString();
    }
}
