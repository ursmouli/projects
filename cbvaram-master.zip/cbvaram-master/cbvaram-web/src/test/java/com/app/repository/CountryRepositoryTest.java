package com.app.repository;

import com.app.entity.Country;
import com.app.entity.State;
import org.hamcrest.Matchers;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import static org.hamcrest.Matchers.*;
import static org.junit.Assert.assertThat;

@RunWith(SpringRunner.class)
@DataJpaTest
public class CountryRepositoryTest {
    @Autowired
    private TestEntityManager testEntityManager;

    @Autowired
    private StateRepository stateRepository;

    @Autowired
    private CountryRepository countryRepository;

    @Test
    public void test_saveCountry() {
        Country dbCountry = countryRepository.findByCode("IND");

        Predicate<State> containsStateAp = state -> state.getCode().equals("AP");

        List<State> dbStateAP = dbCountry.getStates().stream().filter(containsStateAp).collect(Collectors.toList());

        assertThat(dbStateAP, Matchers.<Collection<State>> allOf(
                is(not(empty())),
                hasSize(greaterThan(0)),
                hasItem(hasProperty("code", equalTo("AP")))
        ));

        // assertThat(dbStates, hasItem(hasProperty("code", equalTo("AP"))));
    }

}
