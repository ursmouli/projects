package com.app.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.access.AccessDeniedHandler;

/**
 * @author Mouli
 * 
 * http://docs.spring.io/spring-boot/docs/current/reference/html/howto-security.html
 * Switch off the Spring Boot security configuration
 * 
 * @EnableWebSecurity (using this might impact spring boot security default mechanism)
 *
 */
@Configuration
public class SpringSecurityConfig extends WebSecurityConfigurerAdapter {

	@Autowired
	private AccessDeniedHandler accessDeniedHandler;
    
    @Autowired
    private UserDetailsService userDetailsService;
    
    @Bean
    public BCryptPasswordEncoder bCryptPasswordEncoder() {
        return new BCryptPasswordEncoder();
    }
    
    /**
     * roles admin allow to access /admin/**
     * roles user allow to access /user/**
     * custom 403 access denied handler
     */
	@Override
	protected void configure(HttpSecurity http) throws Exception {
		http.csrf().disable()
					.authorizeRequests()
						.antMatchers("/", "/home", "/about").permitAll()
						.antMatchers("/h2-console/**").permitAll()
						.antMatchers("/register*").permitAll()
						.antMatchers("/admin/**").hasAnyRole("ADMIN")
						.antMatchers("/user/**").hasAnyRole("USER").anyRequest()
					.authenticated()
					.and()
					.formLogin()
						.loginPage("/login").permitAll()
					.and()
					.logout().permitAll().and()
					.exceptionHandling().accessDeniedHandler(accessDeniedHandler);
	}

	/**
	 * Used to configure login validation access to application.
	 * 
	 * For in-memory use auth.inMemoryAuthentication().withUser().withPassword().roles()
	 * 
	 * @param auth - AuthenticationManagerBuilder to apply in-memory or database authentication
	 * @throws Exception
	 */
	@Autowired
	public void configureGlobal(AuthenticationManagerBuilder auth) throws Exception {
		auth.userDetailsService(userDetailsService).passwordEncoder(bCryptPasswordEncoder());
	}

	/*
	 * //Spring Boot configured this already.
	 * 
	 * @Override public void configure(WebSecurity web) throws Exception { web
	 * .ignoring() .antMatchers("/resources/**", "/static/**", "/css/**", "/js/**",
	 * "/images/**"); }
	 */

}
