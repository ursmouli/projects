package com.app.validator;

import com.app.entity.AppUser;
import com.app.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;


@Component
public class AppUserValidator implements Validator {

    @Autowired
    private UserRepository userRepository;

    @Override
    public boolean supports(Class<?> clazz) {
        return clazz == AppUser.class;
    }

    @Override
    public void validate(Object target, Errors errors) {
        AppUser appUser = (AppUser) target;

        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "username", "NotEmpty.UserForm.appUser.username");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "password", "NotEmpty.UserForm.appUser.password");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "email", "NotEmpty.UserForm.appUser.email");

        if (CollectionUtils.isEmpty(appUser.getRoles())) {
            errors.rejectValue("roles", "NotEmpty.UserForm.appUser.roles");
        }

        if (!StringUtils.isEmpty(appUser.getUsername())) {
            AppUser dbUser = userRepository.findByUsername(appUser.getUsername());
            if (dbUser != null) {
                errors.rejectValue("username", "Duplicate.UserForm.appUser.username");
            }
        }

        if (!appUser.getPassword().equals(appUser.getConfirmPassword())) {
            errors.rejectValue("confirmPassword", "Match.UserForm.appUser.confirmPassword");
        }

        if (!StringUtils.isEmpty(appUser.getEmail())) {
            AppUser dbUser = userRepository.findByEmail(appUser.getEmail());
            if (dbUser != null) {
                errors.rejectValue("email", "Duplicate.UserForm.appUser.email");
            }
        }
    }
}
