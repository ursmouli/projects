package com.app.service;

import com.app.entity.Blog;
import java.util.List;

public interface BlogService {

	void addBlog(Blog blog);
	
	List<Blog> getAllBlogs();
	
	Blog getBlog(Long id);
}
