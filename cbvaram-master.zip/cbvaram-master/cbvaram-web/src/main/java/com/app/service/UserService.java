package com.app.service;

import com.app.entity.AppUser;

public interface UserService {
	void save(AppUser user);

	AppUser findByUsername(String username);
}
