package com.app.controller;

import com.app.constants.AppPageElementEnum;
import com.app.constants.AppPageNameEnum;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class DefaultController {

    @GetMapping(value = { "/", "/home" })
    public String home(Model model) {
        model.addAttribute(AppPageElementEnum.TITLE.toString(), "Home");
        return AppPageNameEnum.HOME.toString();
    }

    @GetMapping("/about")
    public String about(Model model) {
        model.addAttribute(AppPageElementEnum.TITLE.toString(), "About Page");
        return AppPageNameEnum.ABOUT.toString();
    }

}
