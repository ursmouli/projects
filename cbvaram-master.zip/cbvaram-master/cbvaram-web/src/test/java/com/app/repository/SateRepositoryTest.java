package com.app.repository;

import com.app.entity.Country;
import com.app.entity.State;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@DataJpaTest
public class SateRepositoryTest {

    @Autowired
    private TestEntityManager testEntityManager;

    @Autowired
    private StateRepository stateRepository;

    @Autowired
    private CountryRepository countryRepository;

    @Test
    public void test_saveState() {
        Country country = new Country();
        country.setCode("IND");
        country.setName("India");

        countryRepository.save(country);

        State apState = new State();
        apState.setCode("AP");
        apState.setName("Andhar Pradesh");
        apState.setCountry(country);

        stateRepository.save(apState);

        State katState = new State();
        katState.setCode("KAT");
        katState.setName("Karnataka");
        katState.setCountry(country);

        stateRepository.save(katState);

        State dbState = stateRepository.findByCode("AP");
        System.out.println(dbState.getCountry().getName());
    }
}
