package com.app.service.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.entity.Blog;
import com.app.repository.BlogRepository;
import com.app.service.BlogService;

@Service("blogService")
public class BlogServiceImpl implements BlogService {
	
	private static final Logger LOG = LoggerFactory.getLogger(BlogServiceImpl.class);
	
	@Autowired
	private BlogRepository blogRepository;

	@Override
	public void addBlog(Blog blog) {
		LOG.debug("adding blog : " + blog.getTitle());
		blogRepository.save(blog);
		LOG.debug("added blog : " + blog.getTitle());
	}

	@Override
	public List<Blog> getAllBlogs() {
		return blogRepository.findAll();
	}

	@Override
	public Blog getBlog(Long id) {
		return blogRepository.findOne(id);
	}

}
