package com.app.controller;

import com.app.constants.AppPageElementEnum;
import com.app.constants.AppPageNameEnum;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/admin")
public class AdminController {

    @GetMapping("/home")
    public String home(Model model) {
        model.addAttribute(AppPageElementEnum.TITLE.toString(), "Admin Home");
        return AppPageNameEnum.ADMIN_HOME.toString();
    }
}
