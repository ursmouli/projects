package com.app.repository;

import com.app.entity.AppUser;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.junit4.SpringRunner;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

@RunWith(SpringRunner.class)
@DataJpaTest
public class UserRepositoryTest {

    @Autowired
    private TestEntityManager testEntityManager;

    @Autowired
    private UserRepository userRepository;

    @Test
    public void test_save() {
        AppUser persistUser = new AppUser();
        persistUser.setUsername("user");
        persistUser.setPassword("password");
        userRepository.save(persistUser);

        AppUser appUser = userRepository.findByUsername("user");
        assertThat(appUser.getUsername(), is(equalTo(persistUser.getUsername())));
    }
}
