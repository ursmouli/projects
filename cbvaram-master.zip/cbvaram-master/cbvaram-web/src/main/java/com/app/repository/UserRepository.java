package com.app.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.app.entity.AppUser;

public interface UserRepository extends JpaRepository<AppUser, Long> {
	AppUser findByUsername(String username);

	// Can also use spring data Example (Example<AppUser> emailQuery = Example.of(appUser))
	AppUser findByEmail(String email);
}
