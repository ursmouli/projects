package com.app.controller;

import com.app.constants.AppPageElementEnum;
import com.app.constants.AppPageNameEnum;
import com.app.entity.AppUser;
import com.app.repository.RoleRepository;
import com.app.service.UserService;
import com.app.validator.AppUserValidator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class RegisterController {

    @Autowired
    private AppUserValidator appUserValidator;

    @Autowired
    private RoleRepository roleRepository;

    @Autowired
    private UserService userService;

    @InitBinder
    protected void initBinder(WebDataBinder dataBinder) {
        Object target = dataBinder.getTarget();

        if (target == null) {
            return;
        }

        if (target.getClass() == AppUser.class) {
            dataBinder.setValidator(appUserValidator);
        }
    }

    @GetMapping("/register")
    public String registerPage(Model model) {
        AppUser appUser = new AppUser();
        model.addAttribute("appUser", appUser);
        model.addAttribute(AppPageElementEnum.TITLE.toString(), "Registration");
        model.addAttribute("userRoles", roleRepository.findAll());
        return AppPageNameEnum.REG_PAGE.toString();
    }

    /**
     * Register user.
     *
     * @param model to store page data
     * @param appUser user form
     * @param bindingResult to bind error result to page
     * @param redirectAttributes redirect attributes
     * @return page
     */
    @PostMapping("/register")
    public String register(Model model,
                           @ModelAttribute("appUser") @Validated AppUser appUser,
                           BindingResult bindingResult,
                           final RedirectAttributes redirectAttributes) {

        if (bindingResult.hasErrors()) {
            model.addAttribute("userRoles", roleRepository.findAll());
            return AppPageNameEnum.REG_PAGE.toString();
        }

        redirectAttributes.addFlashAttribute("flashUser", appUser);

        userService.save(appUser);

        return "redirect:/login";
    }
}
